Place your local font files here (woff2 recommended).

Expected filenames (examples used by the project):
- Cairo-Regular.woff2
- Cairo-Bold.woff2
- Outfit-Regular.woff2
- Outfit-Medium.woff2

If you use other font filenames, update `client/src/app/globals.css` @font-face `src` URLs accordingly.

You can obtain the fonts from Google Fonts and export them as woff2, or provide licensed font files.
